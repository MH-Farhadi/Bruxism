"""Draw the microphone-contamination evidence figures from ``data/audit.json``.

Every figure answers one question an advisor will actually ask, in this order:

  fig1  Where is the repetition?              -> the channel identity matrix
  fig2  Is it really the same data?           -> two participants, overlaid, difference zero
  fig3  How bad, and is the EMG affected?     -> distinct waveforms per channel
  fig4  What did it do to the results?        -> LOSO exposure and the S05 dissociation
  fig5  Could we still use it as audio?       -> the spectrum says it is not audio
  fig6  Would a clinician see the problem?    -> clenching is quieter than quiet rest
  fig7  What broke, mechanically?             -> the rotation offsets, a ring-buffer trace

Run:  python advisor/make_figures.py
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.patches as mpatches  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.colors import ListedColormap  # noqa: E402
from scipy.signal import butter, sosfiltfilt, sosfreqz, welch  # noqa: E402

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
FIG = HERE / "figures"
DATA = HERE / "data"

plt.rcParams.update(
    {
        "figure.dpi": 160,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.titleweight": "bold",
        "axes.labelsize": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linewidth": 0.6,
        "legend.frameon": False,
        "legend.fontsize": 8,
    }
)

BAD = "#c1272d"  # the contaminated channel
GOOD = "#0b6e4f"  # the clean control
NEUTRAL = "#4a5568"
ACCENT = "#1f6feb"
SUBJECT_COLORS = ["#1f6feb", "#e07b00", "#0b6e4f", "#8b3fa8", "#c1272d"]

EMG_COLUMNS = ["EMG1_1-2", "EMG2_3-4", "EMG3_5-6", "EMG4_7-8"]
FS = 1200.0


def load() -> dict:
    return json.loads((DATA / "audit.json").read_text())


def save(fig: plt.Figure, name: str) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(FIG / f"{name}.{ext}")
    plt.close(fig)
    print(f"  wrote figures/{name}.png / .pdf")


def ordered_records(audit: dict) -> list[dict]:
    """Recordings sorted by subject, then class, then condition — the matrix row order."""
    class_order = {"rest": 0, "movement": 1, "clenching": 2, "grinding": 3, "chewing": 4}
    return sorted(
        audit["records"],
        key=lambda r: (r["subject"], class_order[r["label"]], r["condition"], r["recording_id"]),
    )


# ---------------------------------------------------------------------------------------
# Figure 1 — the channel identity matrix
# ---------------------------------------------------------------------------------------
def fig1_identity_matrix(audit: dict) -> None:
    records = ordered_records(audit)
    n = len(records)
    subjects = [r["subject"] for r in records]

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 6.0))
    cross_counts: dict[str, int] = {}

    for ax, (channel, key, title) in zip(
        axes,
        [
            ("mic", "mic_fp", "Microphone channel"),
            ("emg", "EMG1_1-2_fp", "EMG channel 1  (control)"),
        ],
    ):
        fingerprints = [r[key] for r in records]
        same = np.array([[a == b for b in fingerprints] for a in fingerprints], dtype=float)
        cross = np.array(
            [
                [
                    (fa == fb) and (sa != sb)
                    for fb, sb in zip(fingerprints, subjects)
                ]
                for fa, sa in zip(fingerprints, subjects)
            ],
            dtype=bool,
        )
        # 0 = different, 1 = identical within a participant, 2 = identical ACROSS participants
        grid = np.where(cross, 2.0, same)

        cmap = ListedColormap(["#f2f4f7", "#9aa5b1", BAD])
        ax.imshow(grid, cmap=cmap, vmin=0, vmax=2, interpolation="nearest")

        # Participant block boundaries.
        edges = [i for i in range(1, n) if subjects[i] != subjects[i - 1]]
        for e in edges:
            ax.axhline(e - 0.5, color="black", lw=1.1)
            ax.axvline(e - 0.5, color="black", lw=1.1)

        starts = [0, *edges, n]
        for i in range(len(starts) - 1):
            mid = (starts[i] + starts[i + 1]) / 2 - 0.5
            label = subjects[starts[i]]
            ax.text(mid, -2.5, label, ha="center", va="bottom", fontsize=9, fontweight="bold")
            ax.text(-2.5, mid, label, ha="right", va="center", fontsize=9, fontweight="bold")

        n_cross = int(cross.sum() // 2)
        distinct = len(set(fingerprints))
        cross_counts[channel] = n_cross
        ax.set_title(
            f"{title}\n{distinct} distinct waveforms in {n} recordings\n"
            f"{n_cross} cross-participant identical pairs",
            color=BAD if channel == "mic" else GOOD,
            pad=16,
            linespacing=1.5,
        )
        ax.set_xticks([])
        ax.set_yticks([])
        ax.grid(False)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_linewidth(0.8)

    handles = [
        mpatches.Patch(facecolor=BAD, label="identical waveform, DIFFERENT participants"),
        mpatches.Patch(facecolor="#9aa5b1", label="identical waveform, same participant"),
        mpatches.Patch(facecolor="#f2f4f7", edgecolor="#cbd2d9", label="different waveforms"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle(
        "Every recording compared against every other, by exact waveform identity",
        fontsize=13.5,
        fontweight="bold",
        y=1.10,
    )
    fig.text(
        0.5,
        1.045,
        "Each cell asks one question: do these two recordings contain the same samples? "
        f"The microphone answers yes across participants for {cross_counts['mic']} pairs "
        "of recordings.\nThe EMG never does, in any of its four channels.",
        ha="center",
        va="top",
        fontsize=9.5,
        color=NEUTRAL,
        linespacing=1.5,
    )
    save(fig, "fig1_identity_matrix")


# ---------------------------------------------------------------------------------------
# Figure 2 — the smoking gun: one waveform, five participants
# ---------------------------------------------------------------------------------------
def fig2_smoking_gun(audit: dict) -> None:
    members = audit["exhibit_group"]["members"]
    by_id = {r["recording_id"]: r for r in audit["records"]}

    mics, emgs, labels = [], [], []
    for rid in members:
        frame = pd.read_csv(by_id[rid]["path"])
        mics.append(frame["Mic"].to_numpy(dtype=np.float64))
        emgs.append(frame["EMG1_1-2"].to_numpy(dtype=np.float64))
        labels.append(by_id[rid]["subject"])

    # Recover each recording's offset relative to the first, then undo it.
    offsets = [0]
    for other in mics[1:]:
        spectrum = np.fft.rfft(mics[0] - mics[0].mean()) * np.conj(
            np.fft.rfft(other - other.mean())
        )
        offsets.append(int(np.argmax(np.fft.irfft(spectrum, n=mics[0].size))))
    aligned = [np.roll(m, off) for m, off in zip(mics, offsets)]
    residual = max(float(np.abs(aligned[0] - a).max()) for a in aligned[1:])

    seconds = np.arange(mics[0].size) / FS
    window = slice(0, int(12 * FS))

    fig, axes = plt.subplots(4, 1, figsize=(11, 10), height_ratios=[2.6, 2.6, 1.0, 2.6])

    ax = axes[0]
    for mic, label, color in zip(mics, labels, SUBJECT_COLORS):
        ax.plot(seconds[window], mic[window], lw=0.9, color=color, label=label, alpha=0.9)
    ax.set_title("A.  As stored — the microphone channel of five different participants")
    ax.set_ylabel("counts")
    ax.legend(ncol=5, loc="upper right")
    ax.text(
        0.012,
        0.06,
        "Same condition (deviation left–right), five people, five sessions, three days.\n"
        "They look shifted in time, not different.",
        transform=ax.transAxes,
        fontsize=8,
        color=NEUTRAL,
        va="bottom",
    )

    ax = axes[1]
    for a, label, color in zip(aligned, labels, SUBJECT_COLORS):
        ax.plot(seconds[window], a[window], lw=1.6, color=color, label=label, alpha=0.65)
    ax.set_title("B.  After undoing a circular shift — the five traces coincide exactly")
    ax.set_ylabel("counts")
    ax.legend(ncol=5, loc="upper right")
    # Report each shift as the shorter way round the circle: a +59.0 s shift of a 60 s
    # recording is a -1.0 s shift, and saying so is what makes the ring-buffer story legible.
    n_samples = mics[0].size
    wrapped = [off if off <= n_samples / 2 else off - n_samples for off in offsets]
    shift_text = ", ".join(
        f"{lab} {off / FS:+.2f}s" for lab, off in zip(labels[1:], wrapped[1:])
    )
    ax.text(
        0.012,
        0.06,
        f"Shifts applied: {shift_text}",
        transform=ax.transAxes,
        fontsize=8,
        color=NEUTRAL,
        va="bottom",
    )

    ax = axes[2]
    for a, color in zip(aligned[1:], SUBJECT_COLORS[1:]):
        ax.plot(seconds[window], (aligned[0] - a)[window], lw=1.0, color=color)
    ax.set_title(
        f"C.  Difference from {labels[0]} after alignment — "
        f"largest absolute difference anywhere in the full 60 s recording: {residual:.0f} counts"
    )
    ax.set_ylabel("counts")
    ax.set_ylim(-1, 1)
    ax.axhline(0, color="black", lw=0.8)

    ax = axes[3]
    # The amplifier settles over the first couple of seconds and that transient is orders of
    # magnitude larger than the muscle activity; showing it would flatten the panel to a line.
    settled = slice(int(3 * FS), int(15 * FS))
    t_emg = np.arange(settled.stop - settled.start) / FS + 3
    for emg, label, color in zip(emgs, labels, SUBJECT_COLORS):
        ax.plot(t_emg, emg[settled], lw=0.6, color=color, label=label, alpha=0.75)
    spread = max(float(np.percentile(np.abs(e[settled]), 99.5)) for e in emgs)
    ax.set_ylim(-1.6 * spread, 1.6 * spread)
    ax.set_title("D.  The EMG from those same five recordings — five different people")
    ax.set_ylabel("µV")
    ax.set_xlabel("seconds")
    ax.legend(ncol=5, loc="upper right")
    ax.text(
        0.012,
        0.04,
        "The EMG is unique to each participant in every one of the 100 recordings.\n"
        "Whatever failed, it failed only on the microphone column.\n"
        "(First 3 s omitted: the amplifier's settling transient would flatten the panel.)",
        transform=ax.transAxes,
        fontsize=8,
        color=NEUTRAL,
        va="bottom",
    )

    fig.suptitle(
        "One microphone waveform, replayed under five different participants",
        fontsize=13,
        fontweight="bold",
        y=0.995,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.975))
    save(fig, "fig2_smoking_gun")

    return residual


# ---------------------------------------------------------------------------------------
# Figure 3 — distinct waveforms per channel
# ---------------------------------------------------------------------------------------
def fig3_distinct_counts(audit: dict) -> None:
    order = ["EMG1_1-2", "EMG2_3-4", "EMG3_5-6", "EMG4_7-8", "trigger", "mic"]
    pretty = ["EMG 1", "EMG 2", "EMG 3", "EMG 4", "Trigger", "Microphone"]
    counts = [audit["duplication"][c]["n_distinct_waveforms"] for c in order]
    affected = [audit["duplication"][c]["n_recordings_affected"] for c in order]
    colors = [GOOD] * 4 + [NEUTRAL, BAD]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.4))

    ax = axes[0]
    bars = ax.bar(pretty, counts, color=colors, width=0.62)
    ax.axhline(100, color="black", ls="--", lw=1.1)
    ax.text(5.42, 101.5, "100 = one per recording", ha="right", fontsize=8, color=NEUTRAL)
    for bar, value in zip(bars, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 2,
            str(value),
            ha="center",
            fontweight="bold",
            fontsize=10,
        )
    ax.set_ylim(0, 115)
    ax.set_ylabel("distinct waveforms")
    ax.set_title("Distinct waveforms in 100 recordings")

    ax = axes[1]
    bars = ax.bar(pretty, affected, color=colors, width=0.62)
    for bar, value in zip(bars, affected):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 2,
            str(value),
            ha="center",
            fontweight="bold",
            fontsize=10,
        )
    ax.set_ylim(0, 115)
    ax.set_ylabel("recordings")
    ax.set_title("Recordings sharing a waveform with a DIFFERENT participant")
    ax.text(
        0.5,
        0.55,
        "The trigger's 5 are the all-zero rest triggers —\n"
        "a binary channel with no events, not copied data.",
        transform=ax.transAxes,
        fontsize=8,
        color=NEUTRAL,
        ha="center",
    )

    fig.suptitle(
        "The defect is confined to one column",
        fontsize=13,
        fontweight="bold",
        y=1.02,
    )
    fig.tight_layout()
    save(fig, "fig3_distinct_counts")


# ---------------------------------------------------------------------------------------
# Figure 4 — what it did to leave-one-subject-out
# ---------------------------------------------------------------------------------------
def fig4_loso_exposure(audit: dict) -> None:
    per_subject = audit["duplication"]["mic"]["affected_per_subject"]
    subjects = sorted(per_subject)
    exposure = [per_subject[s] for s in subjects]

    # Three-seed means read from the published ablation ledger (modality_and_no_chewing,
    # config hash cead62e4). These are the numbers Table 4 of the earlier manuscript rests on.
    audio_f1 = [0.423, 0.425, 0.522, 0.414, 0.354]
    emg_f1 = [0.632, 0.726, 0.713, 0.722, 0.805]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.4))

    ax = axes[0]
    colors = [BAD if e > 10 else "#e8a33d" for e in exposure]
    bars = ax.bar(subjects, exposure, color=colors, width=0.6)
    for bar, value in zip(bars, exposure):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 0.5,
            f"{value}/20",
            ha="center",
            fontweight="bold",
        )
    ax.set_ylim(0, 24)
    ax.set_ylabel("recordings out of 20")
    ax.set_title("Held-out audio that was also in the training set")
    ax.text(
        0.5,
        0.46,
        "Leave-one-subject-out held out\nthe participant.\nIt did not hold out their audio.",
        transform=ax.transAxes,
        ha="center",
        fontsize=9,
        color=NEUTRAL,
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.85, "pad": 4},
    )

    ax = axes[1]
    ax.plot(subjects, audio_f1, "o-", color=BAD, lw=2, ms=8, label="audio-only macro-F1")
    ax.plot(subjects, emg_f1, "s-", color=GOOD, lw=2, ms=8, label="EMG-only macro-F1")
    for x, (a, e) in enumerate(zip(audio_f1, emg_f1)):
        ax.text(x, a - 0.045, f"{a:.3f}", ha="center", fontsize=8, color=BAD)
        ax.text(x, e + 0.028, f"{e:.3f}", ha="center", fontsize=8, color=GOOD)
    ax.axvspan(3.5, 4.5, color="#fff3cd", zorder=0)
    ax.set_ylim(0.28, 0.90)
    ax.set_ylabel("macro-F1 (3-seed mean)")
    ax.set_title("The participant whose audio was NOT copied")
    ax.legend(loc="upper left")
    ax.annotate(
        "S05 has the least duplicated audio (4/20).\n"
        "It is the WORST participant on audio and\n"
        "the BEST on EMG. That dissociation is\n"
        "what leakage looks like — and it is not\n"
        "'S05 is a hard subject', because on EMG\n"
        "S05 is the easiest.",
        xy=(3.92, 0.362),
        xytext=(0.05, 0.545),
        textcoords="axes fraction",
        fontsize=8.2,
        color=NEUTRAL,
        va="top",
        arrowprops={"arrowstyle": "->", "color": NEUTRAL, "lw": 1.2},
    )

    fig.suptitle(
        "The audio ablation scored the training set",
        fontsize=13,
        fontweight="bold",
        y=1.02,
    )
    fig.tight_layout()
    save(fig, "fig4_loso_exposure")


# ---------------------------------------------------------------------------------------
# Figure 5 — the channel is not audio
# ---------------------------------------------------------------------------------------
def fig5_not_audio(audit: dict) -> None:
    cache = np.load(DATA / "spectrum_waveforms.npz")
    mic, emg = cache["mic"], cache["emg"]
    records = audit["records"]

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2))

    ax = axes[0]
    f_mic, p_mic = welch(mic - mic.mean(), FS, nperseg=4096)
    f_emg, p_emg = welch(emg - emg.mean(), FS, nperseg=4096)
    ax.loglog(f_mic[1:], p_mic[1:] / p_mic[1:].max(), color=BAD, lw=1.6, label="Microphone")
    ax.loglog(f_emg[1:], p_emg[1:] / p_emg[1:].max(), color=GOOD, lw=1.2, alpha=0.8, label="EMG")
    sos = butter(2, 20.0, btype="highpass", fs=FS, output="sos")
    w, h = sosfreqz(sos, worN=4096, fs=FS)
    ax.loglog(w[1:], np.abs(h[1:]) ** 2, color=ACCENT, lw=1.4, ls="--", label="20 Hz high-pass")
    ax.axvspan(0.5, 10, color=BAD, alpha=0.10)
    ax.axvline(600, color="black", lw=1.0, ls=":")
    ax.text(300, 3e-9, "Nyquist\n600 Hz", fontsize=7.5, color=NEUTRAL, ha="right")
    ax.text(
        1.6,
        8,
        "96% of the microphone's\npower lives in this band",
        fontsize=8.5,
        color=BAD,
        ha="center",
        fontweight="bold",
    )
    ax.set_xlabel("frequency (Hz)")
    ax.set_ylabel("normalised power")
    ax.set_ylim(1e-9, 200)
    ax.set_title("Where the microphone's energy is", pad=10)
    ax.legend(loc="lower left", fontsize=7.5)

    ax = axes[1]
    fractions = [r["mic_frac_below_10hz"] * 100 for r in records]
    ax.hist(fractions, bins=22, color=BAD, alpha=0.85, edgecolor="white")
    ax.axvline(float(np.median(fractions)), color="black", lw=1.4, ls="--")
    ax.text(
        float(np.median(fractions)) - 0.4,
        ax.get_ylim()[1] * 0.9,
        f"median {np.median(fractions):.1f}%",
        ha="right",
        fontsize=8.5,
        fontweight="bold",
    )
    ax.set_xlabel("% of channel power below 10 Hz")
    ax.set_ylabel("recordings")
    ax.set_title("All 100 recordings agree")
    ax.text(
        0.03,
        0.60,
        "A microphone recording of tooth\ncontact puts its energy in the\nkilohertz range. This channel\nputs 91–99% of it below 10 Hz.\n\n"
        "It is a sound-level envelope,\nnot an acoustic waveform.",
        transform=ax.transAxes,
        fontsize=8,
        color=NEUTRAL,
        va="top",
    )

    ax = axes[2]
    excerpt = slice(int(20 * FS), int(23 * FS))
    t = np.arange(excerpt.stop - excerpt.start) / FS
    values = mic[excerpt]
    ax.step(t, values, where="mid", color=BAD, lw=1.2)
    ax.set_xlabel("seconds")
    ax.set_ylabel("counts")
    ax.set_title("The samples themselves, zoomed in", pad=10)
    # Leave headroom above the trace for the caption rather than writing over it.
    low, high = float(values.min()), float(values.max())
    ax.set_ylim(low - 0.6, high + 0.6 + 2.2 * max(high - low, 1.0))
    ax.set_yticks(np.arange(low, high + 1))
    steps = sorted({r["mic_quant_step"] for r in records})
    uniq = [r["mic_n_unique"] for r in records]
    ax.text(
        0.5,
        0.97,
        f"A 3-second excerpt. The channel takes only\n"
        f"{int(high - low) + 1} distinct values across the whole window.\n\n"
        f"Integer-valued, step = {steps[0]:.0f} count in all 100\n"
        f"recordings; {min(uniq)}–{max(uniq)} distinct values in 60 s.\n\n"
        "The production 20 Hz high-pass keeps a median\n"
        "1.19% of the variance, and what survives for\n"
        "clenching and grinding sits at or below this\n"
        "1-count quantisation floor.",
        transform=ax.transAxes,
        fontsize=8,
        color=NEUTRAL,
        va="top",
        ha="center",
    )

    fig.suptitle(
        "Even if it were not duplicated, this channel is not usable audio",
        fontsize=13,
        fontweight="bold",
        y=1.02,
    )
    fig.tight_layout()
    save(fig, "fig5_not_audio")


# ---------------------------------------------------------------------------------------
# Figure 6 — the physically impossible contrast
# ---------------------------------------------------------------------------------------
def fig6_contrast(audit: dict) -> None:
    """Activity loudness relative to that participant's own quiet rest.

    The EMG is measured through the manuscript's own analysis band (20-450 Hz) rather than
    raw: the raw column is dominated by the amplifier's settling transient, and comparing
    an unfiltered RMS against rest would measure the transient, not the muscle. The
    microphone is measured raw, because raw is what it is — a sound-level envelope whose
    content lives below 10 Hz (fig. 5), so band-passing it to the EMG's band would leave
    nothing to compare. Both skip the first 2 s and use trigger-active samples only.
    """
    records = audit["records"]
    classes = ["chewing", "movement", "grinding", "clenching"]
    sos_emg = butter(4, [20.0, 450.0], btype="bandpass", fs=FS, output="sos")

    measured: dict[str, tuple[str, str, float, float]] = {}
    for r in records:
        frame = pd.read_csv(r["path"])
        trigger = frame["Trigger"].to_numpy(dtype=np.float64)
        mic = frame["Mic"].to_numpy(dtype=np.float64)
        emg = frame["EMG1_1-2"].to_numpy(dtype=np.float64)

        mask = np.zeros(trigger.size, dtype=bool)
        mask[int(2 * FS) :] = True
        active = mask & (trigger > 0.5)
        if active.sum() < FS:
            active = mask

        emg_filtered = sosfiltfilt(sos_emg, emg)
        measured[r["recording_id"]] = (
            r["subject"],
            r["label"],
            float(np.std(mic[active])),
            float(np.sqrt(np.mean(emg_filtered[active] ** 2))),
        )

    rest = {s: (m, e) for s, l, m, e in measured.values() if l == "rest"}
    mic_ratios: dict[str, list] = {c: [] for c in classes}
    emg_ratios: dict[str, list] = {c: [] for c in classes}
    for subject, label, mic_rms, emg_rms in measured.values():
        if label == "rest" or subject not in rest:
            continue
        mic_ratios[label].append((subject, mic_rms / rest[subject][0]))
        emg_ratios[label].append((subject, emg_rms / rest[subject][1]))

    fig, axes = plt.subplots(1, 2, figsize=(12, 5.2), sharey=True)
    positions = np.arange(len(classes))
    rng = np.random.default_rng(0)

    for ax, ratios, color, name in [
        (axes[0], emg_ratios, GOOD, "EMG  (20–450 Hz analysis band)"),
        (axes[1], mic_ratios, BAD, "Microphone  (raw channel)"),
    ]:
        for x, cls in zip(positions, classes):
            values = np.array([v for _, v in ratios[cls]])
            jitter = rng.uniform(-0.16, 0.16, values.size)
            ax.scatter(
                x + jitter, values, s=26, color=color, alpha=0.55, edgecolor="none", zorder=3
            )
            median = float(np.median(values))
            ax.plot([x - 0.30, x + 0.30], [median, median], color="black", lw=2.2, zorder=5)
            ax.text(
                x + 0.34,
                median,
                f"{median:.2f}×",
                va="center",
                fontsize=9,
                fontweight="bold",
                zorder=6,
            )

        ax.axhline(1.0, color="black", lw=1.3, ls="--", zorder=2)
        ax.set_yscale("log")
        ax.set_xticks(positions)
        ax.set_xticklabels([c.capitalize() for c in classes])
        ax.set_xlim(-0.6, len(classes) - 0.15)
        ax.set_title(name, color=color)

    axes[0].set_ylabel("amplitude ÷ that participant's own quiet rest")
    axes[0].text(
        -0.55,
        1.06,
        "louder than rest  ↑",
        fontsize=8.5,
        color=NEUTRAL,
        va="bottom",
    )
    axes[0].text(
        -0.55,
        0.94,
        "quieter than rest  ↓",
        fontsize=8.5,
        color=NEUTRAL,
        va="top",
    )
    axes[0].text(
        0.5,
        0.03,
        "Every activity sits above that person's own quiet rest,\nand the ordering is the "
        "physiological one.",
        transform=axes[0].transAxes,
        ha="center",
        fontsize=8.5,
        color=NEUTRAL,
    )
    axes[1].text(
        0.03,
        0.03,
        "Clenching and grinding — the two behaviours\nthe study exists to measure — sit "
        "BELOW\na closed, silent mouth.\nNo working microphone does this.",
        transform=axes[1].transAxes,
        ha="left",
        fontsize=8.5,
        color=BAD,
        fontweight="bold",
    )

    fig.suptitle(
        "Every activity should be louder than silence. On the microphone channel, they are not.",
        fontsize=13,
        fontweight="bold",
        y=1.02,
    )
    fig.text(
        0.5,
        0.965,
        "One point per recording, against that same participant's own rest session. "
        "Black bar = class median.",
        ha="center",
        fontsize=8.5,
        color=NEUTRAL,
    )
    fig.tight_layout()
    save(fig, "fig6_contrast")


# ---------------------------------------------------------------------------------------
# Figure 7 — the mechanism
# ---------------------------------------------------------------------------------------
def fig7_offsets(audit: dict) -> None:
    rotations = [r for r in audit["rotations"] if r["is_exact_rotation"]]
    by_id = {r["recording_id"]: r for r in audit["records"]}
    # A shift of +59 s in a 60 s recording is a shift of -1 s. Wrapping to the shorter way
    # round the circle is what shows that the offsets cluster near zero in both directions.
    wrapped = []
    for r in rotations:
        duration = by_id[r["reference"]]["n_samples"] / audit["sampling_rate"]
        shift = r["offset_seconds"]
        wrapped.append(shift - duration if shift > duration / 2 else shift)
    wrapped = np.array(wrapped)

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.6), width_ratios=[1.0, 1.25])

    ax = axes[0]
    ax.hist(wrapped, bins=28, color=BAD, alpha=0.85, edgecolor="white")
    ax.axvline(0, color="black", lw=1.0, ls="--")
    ax.set_xlabel("circular shift between two participants' copies (seconds)")
    ax.set_ylabel("recording pairs")
    ax.set_title(f"Shifts across all {len(rotations)} confirmed pairs", pad=10)
    ax.text(
        0.5,
        -0.30,
        f"All {len(rotations)} of {len(rotations)} pairs tested are EXACT circular rotations:\n"
        "every sample matches, bit for bit, once shifted.\n"
        "The shifts are small and wrap in both directions — the\n"
        "signature of a ring buffer whose read pointer was never\n"
        "reset between sessions, not of a resampling or export step.",
        transform=ax.transAxes,
        fontsize=8.5,
        color=NEUTRAL,
        ha="center",
        va="top",
    )

    ax = axes[1]
    ax.axis("off")
    groups = audit["duplication"]["mic"]["groups"]
    rows = []
    for fingerprint, members in sorted(groups.items(), key=lambda kv: (-len(kv[1]), kv[0]))[:10]:
        subs = sorted({by_id[m]["subject"] for m in members})
        conds = sorted({by_id[m]["condition"] for m in members})
        cond_text = conds[0] if len(conds) == 1 else f"{conds[0]} (+{len(conds) - 1})"
        rows.append([fingerprint, f"{len(members)}", ", ".join(subs), cond_text])

    table = ax.table(
        cellText=rows,
        colLabels=["waveform id", "copies", "participants", "condition"],
        cellLoc="left",
        colWidths=[0.19, 0.11, 0.31, 0.39],
        loc="upper center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8.5)
    table.scale(1, 1.5)
    for (row, _), cell in table.get_celld().items():
        cell.set_edgecolor("#dfe3e8")
        if row == 0:
            cell.set_facecolor("#f2f4f7")
            cell.set_text_props(fontweight="bold")
    ax.set_title(
        f"The {len(groups)} cross-participant groups (10 largest shown)",
        pad=14,
    )
    ax.text(
        0.5,
        -0.30,
        "Each row is one waveform stored under several participants, under the same condition.\n"
        "The copies are organised by condition, not by session — which is what makes this a\n"
        "labelled-data problem rather than merely a repeated file.",
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=8.5,
        color=NEUTRAL,
    )

    fig.suptitle(
        "How the copies are organised, and what that says about the cause",
        fontsize=13,
        fontweight="bold",
        y=1.02,
    )
    fig.tight_layout()
    save(fig, "fig7_offsets")


def main() -> None:
    audit = load()
    print("drawing figures:")
    fig1_identity_matrix(audit)
    residual = fig2_smoking_gun(audit)
    fig3_distinct_counts(audit)
    fig4_loso_exposure(audit)
    fig5_not_audio(audit)
    fig6_contrast(audit)
    fig7_offsets(audit)
    print(f"\nmax residual after de-rotation, exhibit group: {residual}")


if __name__ == "__main__":
    main()
