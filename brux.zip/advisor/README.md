# Advisor briefing package — microphone channel

Local only. `advisor/` is in `.gitignore` and is never committed.

## Start here

**`briefing.pdf`** (12 pp) — the whole argument. Read it before the meeting. It has the
finding, the seven figures with the sentence to say for each, the mechanism, what is and
is not affected, the NIH argument, seven anticipated questions with answers, and the venue
shortlist.

## What's in here

| File | What it is |
|---|---|
| `briefing.pdf` / `briefing.tex` | The briefing document. Recompile with `pdflatex briefing.tex` (twice). |
| `figures/*.png`, `figures/*.pdf` | The seven evidence figures, standalone. PDF is vector — use it for slides or a grant. |
| `run_audit.py` | Measurement pass. Reads `Data/`, writes `data/audit.json`. ~4 min. |
| `make_figures.py` | Draws the figures from `data/audit.json`. Seconds. |
| `data/audit.json` | Every number in the briefing, per recording. |

## Reproducing

```bash
cd /home/kye/Desktop/Depo/Code/Bruxism
python advisor/run_audit.py      # Data/ -> advisor/data/audit.json
python advisor/make_figures.py   # audit.json -> advisor/figures/
```

This recomputes the audit independently of `Code/src/bruxism/preprocessing/mic_integrity.py`
(it calls that module's functions, but drives them from the raw CSVs rather than the manifest).
The result agrees exactly with the original August 2026 audit.

## The figures

| Figure | Answers |
|---|---|
| `fig1_identity_matrix` | Where is the repetition? — mic vs EMG, every recording against every other |
| `fig2_smoking_gun` | Is it really the same data? — five participants, one waveform, difference exactly 0 |
| `fig3_distinct_counts` | How bad, and is the EMG affected? — 37/100 vs 100/100 |
| `fig4_loso_exposure` | What did it do to the results? — LOSO exposure and the S05 dissociation |
| `fig5_not_audio` | Could we still use it as audio? — 96% below 10 Hz, 1-count step |
| `fig6_contrast` | Would a clinician see it? — clenching quieter than a silent mouth |
| `fig7_offsets` | What broke? — ring-buffer offsets, copies grouped by condition |

**Best two for a slide:** `fig1` (the whole finding in one picture) and `fig2` (proof it is
identical, not similar). **Best for a non-engineer:** `fig6`.

## The numbers, for quick reference

- Microphone: **37 distinct waveforms in 100 recordings**; **83 recordings** share a waveform
  with a different participant; **133** cross-participant identical pairs; **63/63** tested
  pairs confirmed as exact circular rotations, max residual **0 counts**.
- EMG: **100/100 distinct on all four channels**, **0** cross-participant sharing.
- Channel character: **96.0%** median power below 10 Hz; **1.0-count** quantisation step;
  **1.19%** median variance surviving the production 20 Hz high-pass.
- Alignment: median zero-lag envelope correlation **−0.016**, median best lag **18.0 s**
  across the 45 chewing recordings.
- Cause evidence: all three `.npy` companions have an **all-zero mic column** while their EMG
  and trigger match the CSV exactly; all 100 `.avi` files have **zero audio streams**.

## Venue shortlist

Primary path is a journal — the US-only conference constraint is binding this cycle
(EMBC 2027 Singapore, BSN 2026 Porto, BHI 2026 Hong Kong, NER 2027 Milano, BioCAS 2027 Oslo,
ICASSP 2027 Toronto), and the US conferences that fit had 2026 deadlines that already closed.

**Journals (rolling):** IEEE JBHI *(first choice)* · Biomedical Signal Processing and Control ·
IEEE TBME · IEEE OJEMB *(fast, open access)* · Journal of Oral Rehabilitation *(strategic —
the advisor's own community)*

**US conferences, full papers:** IEEE EMBS BHI 2027 *(US, Nov 2027 — best fit)* ·
AMIA 2027 Amplify, **deadline 3 Sep 2026** *(only one open in the window)* ·
IEEE/ACM CHASE 2027 · IEEE SPMB 2027 *(Philadelphia)* · CHIL 2027

Details, deadlines and fit notes are in §8 of the briefing.
