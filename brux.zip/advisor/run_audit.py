"""Recompute the microphone-channel evidence from the raw CSVs, once, into JSON.

This is the measurement pass. It reads every recording in ``Data/``, fingerprints every
channel, confirms the duplicates exactly, and writes ``advisor/data/audit.json`` plus a
small cache of the waveforms the figures need. ``make_figures.py`` reads that JSON and
draws; it never touches the raw data. Splitting them this way means a figure can be
redrawn in a second without a five-minute reload, and every number in the briefing has a
single origin that can be pointed at.

Run:  python advisor/run_audit.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "Code" / "src"))

from bruxism.preprocessing.mic_integrity import (  # noqa: E402
    is_circular_rotation,
    measure_envelope_alignment,
    power_fraction_below,
    quantisation_step,
    summarise_duplication,
    waveform_fingerprint,
)

DATA = REPO / "Data"
OUT = Path(__file__).resolve().parent / "data"
SAMPLING_RATE = 1200.0

EMG_COLUMNS = ["EMG1_1-2", "EMG2_3-4", "EMG3_5-6", "EMG4_7-8"]

# The five analysis classes, keyed by the condition prefix in the filename. Taken from the
# manuscript's class definitions so the figures speak the paper's vocabulary.
CONDITION_TO_CLASS = {
    "rest": "rest",
    "carrots": "chewing",
    "cheese": "chewing",
    "gum": "chewing",
    "incisor_clench": "clenching",
    "molar_clench": "clenching",
    "natural_bruxing": "grinding",
    "bite_left": "grinding",
    "bite_right": "grinding",
    "open_close": "movement",
    "protrusion_retrusion": "movement",
    "deviation_left_right": "movement",
}


def parse_recording(path: Path) -> dict | None:
    """Pull subject, condition and class out of a recording's path and filename."""
    subject = path.parent.name.replace("Subject_", "S").replace("S", "S0")
    stem = path.stem  # e.g. bite_left_1_20250804_103436
    parts = stem.split("_")
    # Trailing two parts are the date and time; the one before that is the subject number.
    if len(parts) < 4:
        return None
    condition = "_".join(parts[:-3])
    for key in sorted(CONDITION_TO_CLASS, key=len, reverse=True):
        if condition == key:
            return {
                "recording_id": stem,
                "subject": subject,
                "condition": condition,
                "label": CONDITION_TO_CLASS[key],
                "path": str(path),
            }
    return None


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    csvs = sorted(p for p in DATA.rglob("*.csv") if p.parent.name.startswith("Subject_"))
    print(f"found {len(csvs)} recordings")

    records: list[dict] = []
    mic_signals: dict[str, np.ndarray] = {}
    emg_signals: dict[str, np.ndarray] = {}

    for path in csvs:
        meta = parse_recording(path)
        if meta is None:
            print(f"  ! skipped (unparsed name): {path.name}")
            continue
        frame = pd.read_csv(path)
        mic = frame["Mic"].to_numpy(dtype=np.float64)
        trigger = frame["Trigger"].to_numpy(dtype=np.float64)
        emg = {col: frame[col].to_numpy(dtype=np.float64) for col in EMG_COLUMNS}

        meta["n_samples"] = int(mic.size)
        meta["mic_fp"] = waveform_fingerprint(mic)
        meta["trigger_fp"] = waveform_fingerprint(trigger)
        for col in EMG_COLUMNS:
            meta[f"{col}_fp"] = waveform_fingerprint(emg[col])

        # Character of the channel: is it an audio waveform or a sound-level envelope?
        meta["mic_quant_step"] = quantisation_step(mic)
        meta["mic_n_unique"] = int(np.unique(mic).size)
        meta["mic_frac_below_10hz"] = power_fraction_below(mic, SAMPLING_RATE, 10.0)
        meta["mic_min"] = float(mic.min())
        meta["mic_max"] = float(mic.max())

        # Per-condition loudness, relative to that participant's own quiet rest later on.
        active = trigger > 0.5
        if active.sum() > SAMPLING_RATE:
            meta["mic_rms_active"] = float(np.std(mic[active]))
            meta["emg_rms_active"] = float(np.std(emg["EMG1_1-2"][active]))
        else:
            meta["mic_rms_active"] = float(np.std(mic))
            meta["emg_rms_active"] = float(np.std(emg["EMG1_1-2"]))

        # Alignment: does the sound track the muscle? Only meaningful where both should
        # burst together, i.e. the chewing conditions.
        if meta["label"] == "chewing":
            alignment = measure_envelope_alignment(emg["EMG1_1-2"], mic, SAMPLING_RATE)
            meta["r_at_zero"] = float(alignment.r_at_zero)
            meta["best_lag_s"] = float(alignment.best_lag_seconds)
            meta["peak_r"] = float(alignment.peak_r)

        mic_signals[meta["recording_id"]] = mic
        emg_signals[meta["recording_id"]] = emg["EMG1_1-2"]
        records.append(meta)
        print(f"  {meta['recording_id']:<45} {meta['subject']}  {meta['label']}")

    subject_of = {r["recording_id"]: r["subject"] for r in records}

    # --- The duplication pass, per channel -------------------------------------------
    channels = {"mic": "mic_fp", "trigger": "trigger_fp"}
    channels.update({col: f"{col}_fp" for col in EMG_COLUMNS})

    duplication = {}
    for name, key in channels.items():
        fingerprints = {r["recording_id"]: r[key] for r in records}
        duplication[name] = summarise_duplication(fingerprints, subject_of)
        summary = duplication[name]
        print(
            f"{name:<10} distinct={summary['n_distinct_waveforms']:>3}/{summary['n_recordings']}"
            f"  cross-subject groups={summary['n_cross_subject_groups']:>2}"
            f"  affected={summary['n_recordings_affected']:>3}"
        )

    # --- Confirm the mic duplicates are exact rotations, not merely similar ----------
    rotations = []
    for fingerprint, members in duplication["mic"]["groups"].items():
        reference = members[0]
        for member in members[1:]:
            is_rotation, offset = is_circular_rotation(
                mic_signals[reference], mic_signals[member]
            )
            rotations.append(
                {
                    "group": fingerprint,
                    "reference": reference,
                    "member": member,
                    "reference_subject": subject_of[reference],
                    "member_subject": subject_of[member],
                    "is_exact_rotation": bool(is_rotation),
                    "offset_samples": int(offset),
                    "offset_seconds": float(offset / SAMPLING_RATE) if offset >= 0 else None,
                }
            )
    n_exact = sum(1 for r in rotations if r["is_exact_rotation"])
    print(f"\nexact circular rotations confirmed: {n_exact}/{len(rotations)} pairs tested")

    # --- Cache the waveforms the "smoking gun" figure needs --------------------------
    # Pick the group that spans the most participants, for the overlay panel.
    best_group = max(
        duplication["mic"]["groups"].items(),
        key=lambda item: len({subject_of[m] for m in item[1]}),
    )
    exhibit_ids = best_group[1][:2]
    np.savez_compressed(
        OUT / "exhibit_waveforms.npz",
        **{f"mic_{rid}": mic_signals[rid] for rid in exhibit_ids},
        **{f"emg_{rid}": emg_signals[rid] for rid in exhibit_ids},
    )

    # A representative spectrum pair, and the rest group for the class-contrast panel.
    spectrum_id = records[0]["recording_id"]
    np.savez_compressed(
        OUT / "spectrum_waveforms.npz",
        mic=mic_signals[spectrum_id],
        emg=emg_signals[spectrum_id],
    )

    payload = {
        "sampling_rate": SAMPLING_RATE,
        "n_recordings": len(records),
        "records": records,
        "duplication": duplication,
        "rotations": rotations,
        "exhibit_group": {"fingerprint": best_group[0], "members": best_group[1]},
        "exhibit_ids": exhibit_ids,
        "spectrum_id": spectrum_id,
    }
    (OUT / "audit.json").write_text(json.dumps(payload, indent=2, default=float))
    print(f"\nwrote {OUT / 'audit.json'}")


if __name__ == "__main__":
    main()
